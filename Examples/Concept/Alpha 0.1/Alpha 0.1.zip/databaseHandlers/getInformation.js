gameStore = _RECEIVE_GAMESTORES();
players = _RECEIVE_PLAYERS();
events = _RECEIVE_EVENTS();
beacons = _RECEIVE_BEACONS();

console.table(gameStore)
console.table(players)
console.table(events)
console.table(beacons)
